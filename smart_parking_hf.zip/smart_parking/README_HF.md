---
title: Smart Parking Detection
emoji: 🚗
colorFrom: blue
colorTo: green
sdk: streamlit
sdk_version: 1.28.0
app_file: app.py
pinned: false
license: mit
short_description: Real-time parking occupancy detection using YOLOv8 and ROI-based classification
---

# Smart Parking Detection Using Computer Vision

This application detects parking occupancy using YOLOv8 for vehicle detection combined with ROI-based slot classification.

## Features
- Automatic dataset detection (PKLot, CNRPark-EXT)
- Real-time vehicle detection
- Slot-level occupancy classification
- Interactive visualization

## Author
Deeksha Reddy Patlolla - University of Colorado Denver
